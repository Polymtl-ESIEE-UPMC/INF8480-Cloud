package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	int execute(int a, int b) {
		return a + b;
	}
}
